package com.project.agriculturalapp.modals;


public class HorticultureDetailItem {
    private String heading;
    private Integer detail;
    private Integer image;

    public Integer getImage() {
        return image;
    }

    public void setImage(Integer image) {
        this.image = image;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public Integer getDetail() {
        return detail;
    }

    public void setDetail(Integer data) {
        this.detail = data;
    }
}
