# Farming-Assistance
 An Android app to provide details about best farming practices which include the type of seeds to use, type of fertilizers to use and crop that are suitable for the soil type. Also, provide an interface for understanding Government Schemes and give a feature to sell the harvest to the seller without the need of the agent.
 
# Technology Used
  1. SQLite for Database
  2. Government APIs for Data fetching
  
# Features 
  1. Simple and Flexible UI
  2. Fast and Improve performance on lower-performing systems
